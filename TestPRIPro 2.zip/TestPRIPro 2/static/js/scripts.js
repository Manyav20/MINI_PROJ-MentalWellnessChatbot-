// Existing: Expand/Collapse sections (used in About Page)
const disorderSections = document.querySelectorAll('.disorder');
disorderSections.forEach((section) => {
  section.addEventListener('click', () => {
    section.classList.toggle('expanded');
  });
});

// Existing: Smooth Scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    document.querySelector(this.getAttribute('href')).scrollIntoView({
      behavior: 'smooth',
    });
  });
});

// New: Chatbot related JavaScript

const chatWindow = document.getElementById('chatWindow');
const userInput = document.getElementById('userInput');

// Function to send user input to the backend and get the response
async function sendMessage() {
  const userMessage = userInput.value.trim();
  if (!userMessage) return;

  // Append the user message to the chat window
  appendMessage('user', userMessage);

  try {
    // Make a request to the Flask backend (adjust the URL if needed)
    const response = await fetch('/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: userMessage })
    });

    const data = await response.json();
    let botResponse = 'Sorry, something went wrong.'; // Default message

    // If the API responds with a valid response, use it
    if (data.response) {
      botResponse = data.response;
    } else if (data.error) {
      botResponse = `Error: ${data.error}`;
    }

    // Append the bot's response to the chat window
    appendMessage('bot', botResponse);

  } catch (error) {
    console.error('Error:', error);
    appendMessage('bot', 'Error: Unable to reach the server.');
  }

  userInput.value = '';  // Clear the input field
}

// Function to check for 'Enter' key press
function checkEnter(event) {
  if (event.key === "Enter") {
    sendMessage();
  }
}

// Function to append messages to the chat window
function appendMessage(sender, message) {
  const messageElement = document.createElement('div');
  messageElement.classList.add('message', sender);
  messageElement.textContent = message;
  chatWindow.appendChild(messageElement);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}
