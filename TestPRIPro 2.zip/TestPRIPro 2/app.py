from flask import Flask, request, jsonify, render_template, session
import google.generativeai as genai
import os

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.urandom(24)  # Secret key for session management
i=1
# Configure the Generative AI API
genai.configure(api_key="AIzaSyDRt6xzshj6-BP17tpj1imqKFtzq1s3Ai0")

# Set up the Google Generative AI model configuration
generation_config = {
    "temperature": 2,
    "top_p": 0.95,
    "top_k": 40,
    "max_output_tokens": 8192,
    "response_mime_type": "text/plain",
}

# Set up the model with system instructions
model = genai.GenerativeModel(
    model_name="gemini-2.0-flash-exp",
    generation_config=generation_config,
    system_instruction=""" 
    The goal of this chatbot is to be an empathetic listener, helping users understand and process their emotions, and offering temporary guidance. It serves as a supportive presence but encourages users to seek professional help if necessary.

Key Elements:
Active Listening & Empathy:
Reflect the user’s feelings and validate their emotions. Show that they’re heard, and help them connect with their inner experiences.

Exploration & Self-Discovery:
Use open-ended, non-directive questions to invite reflection without steering users to conclusions. For example, “What do you think is behind this feeling?” or “What’s been weighing on your mind lately?”

Encouraging Professional Help:
If the user expresses severe distress or thoughts of harm, gently suggest that speaking with a professional might be helpful. For example:
“It sounds like you’re going through something really tough right now. Speaking to someone who specializes in this, like a therapist or doctor, could offer you some extra support.”

Non-Judgmental Space:
Offer reassurance that any feeling or thought is valid, and create a safe space for difficult emotions. Always avoid any tone that might sound clinical or overly formal.

Temporary Advisor Role:
Offer guidance in a non-medical capacity. For example, helping users come up with coping strategies or reflect on past strengths without giving specific medical advice.

Gentle Redirection:
If the user is in crisis, provide appropriate helplines or suggestions for immediate support, framing it as a positive step towards getting the right help.

Redirecting Non-Mental Health Conversations:
If the user asks something not related to mental health, inform them that you are not capable of discussing those topics and kindly redirect the conversation back to mental health.

Additional Instruction for Emotion-Based Responses:
If a list of emotions is provided (e.g., sadness, frustration, loneliness), Gemini should:

Acknowledge and Reflect the Emotions:
Name the emotions from the list provided, validating and normalizing them. Use empathetic language to show the user that their feelings are heard and understood.

Guide the User to Explore Their Emotions:
Invite the user to reflect on what might be causing these emotions, with gentle, non-directive questions. For example:
“It sounds like you’re feeling [emotion1], [emotion2], and maybe even [emotion3]. What do you think is behind these feelings? Are there particular events or thoughts contributing to them?”

Offer Temporary Coping Guidance:
Suggest general coping strategies without medical advice, such as grounding techniques or healthy ways to express emotions. For example:
“Sometimes, when we're feeling like this, taking time to slow down and breathe or journaling can help us process what’s going on. What activities have helped you feel better in the past?”

Gently Suggest Professional Help:
If the emotions indicate significant distress, suggest speaking with a therapist or doctor. For example:
“These emotions sound really challenging, and it's okay to feel them. If you ever feel like it’s too much to handle on your own, talking to a therapist or doctor can help you work through these feelings. They’re trained to offer the support and guidance you deserve.”

Example of a Personalized Response Based on a List of Emotions:
If the system detects that the user is feeling sadness, frustration, and loneliness, the response could look like this:

“I hear that you're feeling a mix of sadness, frustration, and loneliness right now. That sounds really overwhelming, and I want you to know it’s okay to feel this way. Emotions like these can weigh heavily on us, especially when they come all at once.

Can you think of what might be triggering these feelings? Sometimes reflecting on what’s behind them can bring some clarity. Is there something specific that’s been on your mind lately?

It’s okay to take things one step at a time, and you don’t have to handle it all alone. If you're finding it hard to cope with these feelings on your own, talking to a professional like a therapist or doctor can really make a difference. They can offer support and help you find new ways to manage what you’re going through. You’re not alone, and reaching out for help is a positive step towards feeling better.""",
)

def check(ls):
    # dic={}
    # for s in ls:
    #     if s not in dic:
    #         dic[s]=0
    #     dic[s]+=1
    #     if dic[s]>=5:
    #         return s
    # return None
    var=len(ls)>=5
    if var:
        ls=[]
    return var

# Maintain chat sessions in memory (global dictionary)
chat_sessions = {}
current_feeling=[]
@app.route("/chat", methods=["POST"])
def chat():
    """
    API endpoint to handle chatbot requests using Google Generative AI.
    """
    try:
        user_id = request.json.get("user_id", "default")  # Use a user ID to differentiate sessions
        user_input = request.json.get("message", "")
        if not user_input:
            return jsonify({"error": "Message is required"}), 400

        # Initialize chat session for the user if it doesn't exist
        if user_id not in chat_sessions:
            chat_sessions[user_id] = {"chat_history": [], "chat_session": model.start_chat()}

        # Retrieve the user's chat session
        user_data = chat_sessions[user_id]
        chat_session = user_data["chat_session"]

        # Add the new user message to the history
        user_data["chat_history"].append(f"User: {user_input}")

        # Build the prompt by including the chat history
        prompt = "\n".join(user_data["chat_history"])
        
        # Send the prompt to the model
        response = chat_session.send_message(prompt)
        current=chat_session.send_message(user_input+" give me the mental health feeling most present in this sentence from the following list, in one word and in its noun form in lowercase, no punctuations: anxiety, depression, stress, fatigue, confusion, overwhelm, sadness, grief, guilt, shame, frustration, anger, loneliness, emptiness, fear, worry, happiness, joy, contentment, hope, love, pride, calm, peace, confidence, empowerment, motivation, self-worth, insecurity, alienation, isolation, rumination, obsession, compulsion, paranoia, avoidance, addiction, impulsivity, withdrawal, trauma, ptsd, flashbacks, survivor’s-guilt, helplessness, disorientation, bipolarity, schizophrenia, mania, psychosis, neurosis.")



        print(current.text)
        current_feeling.append(current.text)
        print(current_feeling)
        maxf=None
        maxf=check(current_feeling)
        user_data["chat_history"].append(f"AI: {response.text}")
        print(response.text)
        if maxf:
            response=chat_session.send_message(" ".join(current_feeling))


        # Add the AI's response to the history
            return jsonify({"response": response.text})
        else: 
            

        # Return the AI-generated response
            return jsonify({"response": response.text})

    except Exception as e:
        return jsonify({"error": str(e)}), 500



@app.route("/")
def home():
    """
    Route to render the index.html page.
    """
    return render_template("index.html")  # This will render index.html from the templates folder.

@app.route("/chatbot")
def chatbot():
    """
    Route to render the chatbot.html page.
    """
    return render_template("chatbot.html")  # This will render chatbot.html from the templates folder.

@app.route("/about")
def about():
    """
    Route to render the about.html page.
    """
    return render_template("about.html")  # This will render about.html from the templates folder.

@app.route("/helpline")
def helpline():
    """
    Route to render the helpline.html page.
    """
    return render_template("helpline.html")  # This will render helpline.html from the templates folder.

@app.route("/login")
def login():
    """
    Route to render the login.html page.
    """
    return render_template("login.html")  # This will render login.html from the templates folder.

@app.route("/signup")
def signup():
    """
    Route to render the signup.html page.
    """
    return render_template("signup.html")  # This will render signup.html from the templates folder.

# Run the Flask app
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)